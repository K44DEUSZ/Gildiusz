import {
  appendFileSync,
  closeSync,
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  openSync,
  readFileSync,
  realpathSync,
  renameSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, resolve, basename } from "node:path";
import { execFileSync, spawn } from "node:child_process";
import { archiveName, validateBuild, verifyArchive } from "./build-package.mjs";
import { cleanLegacyBuild, pruneReleases, rotateLogs } from "./maintenance.mjs";
import { fileURLToPath, pathToFileURL } from "node:url";
import {
  validatePackagePath,
  validatePackageFile,
  validateRuntimeTree,
  assertRuntimePackage,
  assertDeploymentRuntime,
} from "./runtime-package.mjs";
import { setTimeout as delay } from "node:timers/promises";
import { randomUUID } from "node:crypto";
import { parseEnv } from "node:util";
import { privateDirectory, regularFile, syncDirectory } from "../dist/storage/recovery/files.js";
import { readOffsiteFile, writeOffsiteFile } from "./backup-offsite.mjs";
import { assertSameDeploymentState } from "./deployment-state.mjs";

export const repository = "https://github.com/K44DEUSZ/Gildiusz.git";
export function expectedRepository(remote) {
  return remote.toLowerCase() === repository.toLowerCase();
}
const environment = { ...process.env, PATH: `${dirname(process.execPath)}:${process.env.PATH}` };
// Daily recovery runs with an operator key. Resuming must not pass it to a long-lived process.
for (const name of Object.keys(environment))
  if (name.toUpperCase() === "BACKUP_ENCRYPTION_KEY") delete environment[name];

function paths(root) {
  return {
    shared: join(root, "shared"),
    state: join(root, "shared", "supervisor.json"),
    health: join(root, "shared", "data", "health.json"),
    database: join(root, "shared", "data", "gildiusz.sqlite"),
    pause: join(root, "shared", "paused"),
    restart: join(root, "shared", "restart"),
    current: join(root, "current"),
  };
}

function readJson(path) {
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch {
    return null;
  }
}
function entryExists(path) {
  return lstatSync(path, { throwIfNoEntry: false }) !== undefined;
}

function atomicJson(path, value) {
  const text = JSON.stringify(value) + "\n";
  writeFileSync(`${path}.tmp`, text, { mode: 0o600 });
  try {
    renameSync(`${path}.tmp`, path);
  } catch (error) {
    // Windows readers can temporarily deny replacement; Linux hosting keeps atomic renames.
    if (process.platform !== "win32" || error.code !== "EPERM") throw error;
    writeFileSync(path, text, { mode: 0o600 });
    rmSync(`${path}.tmp`, { force: true });
  }
}

function event(root, message) {
  const line = `${new Date().toISOString()} ${message}\n`;
  appendFileSync(join(root, "shared", "logs", "hosting.log"), line, { mode: 0o600 });
  console.log(line.trim());
}

export function healthy(health, now = Date.now(), after = 0) {
  return Boolean(health?.ready && health.updated >= after && now - health.updated < 60000);
}

export function checkedRun(runs, sha, branch) {
  return runs.some(
    (run) =>
      run.head_sha === sha &&
      run.head_branch === branch &&
      run.event === "push" &&
      run.status === "completed" &&
      run.conclusion === "success" &&
      run.path === ".github/workflows/check.yml",
  );
}

export async function supervise(root, options = {}) {
  const p = paths(root);
  const assertApplicationEnvironment = () => {
    if (!options.workerArguments) {
      const values = parseEnv(readFileSync(join(p.shared, ".env"), "utf8"));
      if (Object.keys(values).some((name) => name.toUpperCase() === "BACKUP_ENCRYPTION_KEY"))
        throw Error("Keep the backup key in the separate private operator environment.");
    }
  };
  assertApplicationEnvironment();
  const supervisorRevision = basename(realpathSync(p.current));
  const previous = readJson(p.state);
  if (process.platform === "linux" && previous?.childPid && previous?.childBirth) {
    const matchesPreviousWorker = () => {
      try {
        const birth = readFileSync(`/proc/${previous.childPid}/stat`, "utf8")
          .split(") ")[1]
          .split(" ")[19];
        const command = readFileSync(`/proc/${previous.childPid}/cmdline`, "utf8").split("\0");
        return (
          birth === previous.childBirth &&
          command.includes("--env-file=" + join(p.shared, ".env")) &&
          realpathSync(`/proc/${previous.childPid}/cwd`) ===
            join(root, "releases", previous.release)
        );
      } catch {
        return false;
      }
    };
    if (matchesPreviousWorker()) {
      event(root, `stopping orphan worker pid=${previous.childPid}`);
      process.kill(previous.childPid, "SIGTERM");
      const deadline = Date.now() + 20000;
      while (matchesPreviousWorker() && Date.now() < deadline) await delay(250);
      if (matchesPreviousWorker()) process.kill(previous.childPid, "SIGKILL");
    }
  }
  let child;
  let childBirth;
  let started = 0;
  let release;
  let stopping = false;
  let restartValue = "";
  let restarts = 0;
  let nextStart = 0;
  let terminationAt = 0;
  const interval = options.interval ?? 2000;
  const state = () =>
    atomicJson(p.state, {
      supervisorPid: process.pid,
      supervisorRevision,
      childPid: child?.pid ?? null,
      childBirth: child ? childBirth : null,
      release: release ? basename(release) : null,
      started,
      restarts,
      updated: Date.now(),
      paused: existsSync(p.pause),
    });
  const terminate = () => {
    if (child && !terminationAt) {
      terminationAt = Date.now();
      child.kill("SIGTERM");
    }
  };
  const stop = () => {
    stopping = true;
    terminate();
  };
  process.once("SIGTERM", stop);
  process.once("SIGINT", stop);
  try {
    while (!stopping || child) {
      const desired = realpathSync(p.current);
      const requested = existsSync(p.restart) ? readFileSync(p.restart, "utf8") : "";
      if (child) {
        const stale = Date.now() - started > 90000 && !healthy(readJson(p.health));
        if (
          stopping ||
          existsSync(p.pause) ||
          desired !== release ||
          requested !== restartValue ||
          stale
        )
          terminate();
        if (terminationAt && Date.now() - terminationAt > 20000) child.kill("SIGKILL");
      } else if (!stopping && !existsSync(p.pause) && Date.now() >= nextStart) {
        assertApplicationEnvironment();
        release = desired;
        restartValue = requested;
        started = Date.now();
        terminationAt = 0;
        // A new PID must produce a new health signal; a previous process cannot certify it.
        atomicJson(p.health, { ready: false, updated: started });
        const log = openSync(join(p.shared, "logs", "bot.log"), "a", 0o600);
        child = spawn(
          process.execPath,
          options.workerArguments ?? ["--env-file=" + join(p.shared, ".env"), "dist/bot/main.js"],
          { cwd: release, env: environment, stdio: ["ignore", log, log] },
        );
        closeSync(log);
        if (process.platform === "linux" && child.pid) {
          try {
            childBirth = readFileSync(`/proc/${child.pid}/stat`, "utf8")
              .split(") ")[1]
              .split(" ")[19];
          } catch {
            childBirth = null;
          }
        }
        event(root, `worker started pid=${child.pid} revision=${basename(release)}`);
        child.once("exit", (code, signal) => {
          event(root, `worker exited code=${code} signal=${signal}`);
          child = undefined;
          nextStart = Date.now() + (options.restartDelay ?? 5000);
          restarts++;
          state();
        });
        child.once("error", (error) => {
          event(root, `worker spawn error: ${error.code}`);
          child = undefined;
          nextStart = Date.now() + (options.restartDelay ?? 5000);
        });
      }
      state();
      await delay(interval);
    }
  } finally {
    process.removeListener("SIGTERM", stop);
    process.removeListener("SIGINT", stop);
    state();
  }
}

function background(root, command, lock) {
  const log = openSync(join(root, "shared", "logs", "scheduler.log"), "a", 0o600);
  const child = spawn(
    "flock",
    [
      "-o",
      "-n",
      join(root, "shared", lock),
      process.execPath,
      join(root, "current", "scripts", "hosting.mjs"),
      command,
      root,
    ],
    { detached: true, stdio: ["ignore", log, log], env: environment },
  );
  child.on("error", (error) => event(root, `scheduler spawn error: ${error.code}`));
  child.unref();
  closeSync(log);
}

function run(command, args, cwd) {
  return execFileSync(command, args, {
    cwd,
    env: environment,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
    timeout: 300000,
    maxBuffer: 16 * 1024 * 1024,
  }).trim();
}

function pointTo(root, target) {
  const temporary = join(root, "current.next");
  rmSync(temporary, { force: true });
  symlinkSync(target, temporary, "dir");
  renameSync(temporary, join(root, "current"));
}

export async function waitReady(root, revision, after, guildIds, timeout = 100000) {
  const p = paths(root);
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const state = readJson(p.state);
    const health = readJson(p.health);
    if (
      state?.release === revision &&
      state.started >= after &&
      deploymentHealthy(health, guildIds, Date.now(), Math.max(after, state.started))
    )
      return true;
    await delay(2000);
  }
  return false;
}

export async function stopSupervisor(root) {
  const state = readJson(paths(root).state);
  if (!state?.supervisorPid) return;
  const matches = () => {
    try {
      const args = readFileSync(`/proc/${state.supervisorPid}/cmdline`, "utf8").split("\0");
      return args.includes("supervise") && args.includes(root);
    } catch {
      return false;
    }
  };
  if (!matches()) return;
  process.kill(state.supervisorPid, "SIGTERM");
  const deadline = Date.now() + 20000;
  while (matches() && Date.now() < deadline) await delay(250);
  if (matches()) {
    process.kill(state.supervisorPid, "SIGKILL");
    await delay(500);
  }
}

export function startSupervisor(root) {
  if (existsSync(paths(root).pause)) throw Error("The supervisor remains paused.");
  background(root, "supervise", "supervisor.lock");
}

async function checkedWorkflow(sha) {
  const response = await globalThis.fetch(
    `https://api.github.com/repos/K44DEUSZ/Gildiusz/actions/workflows/check.yml/runs?head_sha=${sha}&event=push&per_page=10`,
    {
      headers: { Accept: "application/vnd.github+json" },
      signal: globalThis.AbortSignal.timeout(15000),
    },
  );
  if (!response.ok) throw Error(`GitHub checks unavailable: HTTP ${response.status}`);
  return (await response.json()).workflow_runs?.find((run) => checkedRun([run], sha, "main"));
}

async function download(url, maximum) {
  const response = await globalThis.fetch(url, { signal: globalThis.AbortSignal.timeout(120000) });
  if (!response.ok) throw Error(`Build download HTTP ${response.status}`);
  let length = 0;
  const chunks = [];
  for await (const chunk of response.body) {
    length += chunk.length;
    if (length > maximum) throw Error("Build download exceeds the size limit.");
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

export function validateArchiveEntries(names, types) {
  const allowed = new Set([
    "dist",
    "content",
    "config",
    "scripts",
    "node_modules",
    "package.json",
    "package-lock.json",
    "LICENSE",
    "THIRD_PARTY_NOTICES.md",
    "build.json",
  ]);
  if (names.length !== types.length) throw Error("Incomplete archive listing.");
  for (const [index, raw] of names.entries()) {
    const name = raw.replace(/^\.\//, "");
    if (!name) continue;
    validatePackagePath(raw);
    if (types[index] === "-") validatePackageFile(raw);
    if (
      name.startsWith("/") ||
      name.includes("\\") ||
      name.split("/").includes("..") ||
      !allowed.has(name.split("/")[0])
    )
      throw Error("Unsafe entry in the hosting package.");
  }
  if (types.some((type) => type !== "-" && type !== "d"))
    throw Error("Hosting packages cannot contain links or special files.");
}

export function prepareRelease(root, manifest, bytes) {
  validateBuild(manifest, manifest.revision, manifest.workflowRun);
  verifyArchive(manifest, bytes);
  const releases = join(root, "releases");
  mkdirSync(releases, { recursive: true, mode: 0o700 });
  const release = join(releases, manifest.revision);
  if (existsSync(release)) {
    const previous = readJson(join(release, "build.json"));
    if (
      previous?.revision !== manifest.revision ||
      previous?.workflowRun !== manifest.workflowRun ||
      (previous.runtimeFormat ?? 1) !== (manifest.runtimeFormat ?? 1)
    )
      throw Error("Existing release does not match this build.");
    validateRuntimeTree(release, { allowBuilt: true });
    assertRuntimePackage(release, { format: manifest.runtimeFormat ?? 1 });
    return release;
  }
  const staging = mkdtempSync(join(releases, ".incoming-"));
  if (dirname(staging) !== releases) throw Error("Unexpected staging directory.");
  try {
    const archive = join(staging, archiveName);
    writeFileSync(archive, bytes, { mode: 0o600 });
    const names = run("tar", ["-tzf", archive], root).split("\n");
    const types = run("tar", ["-tvzf", archive], root)
      .split("\n")
      .map((line) => line[0]);
    validateArchiveEntries(names, types);
    execFileSync("tar", ["-xzf", archive, "-C", staging]);
    rmSync(archive);
    const metadata = readJson(join(staging, "build.json"));
    if (
      metadata?.revision !== manifest.revision ||
      metadata?.workflowRun !== manifest.workflowRun ||
      metadata?.nodeMajor !== 24 ||
      (metadata.runtimeFormat ?? 1) !== (manifest.runtimeFormat ?? 1)
    )
      throw Error("Unpacked build identity differs.");
    if (
      !existsSync(join(staging, "dist", "bot", "main.js")) ||
      !existsSync(join(staging, "node_modules", "discord.js", "package.json"))
    )
      throw Error("Incomplete production package.");
    validateRuntimeTree(staging);
    assertRuntimePackage(staging, { format: manifest.runtimeFormat ?? 1 });
    run(process.execPath, ["dist/cli.js", "validate"], staging);
    writeFileSync(join(staging, ".built"), manifest.revision + "\n");
    renameSync(staging, release);
    return release;
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}

async function retrieveRelease(root, sha, workflow) {
  const commit = run(
    "git",
    ["ls-remote", "origin", "refs/heads/hosting-build"],
    join(root, "source"),
  ).split(/\s/)[0];
  if (!/^[a-f0-9]{40}$/.test(commit ?? "")) throw Error("The hosting build is not published yet.");
  const base = `https://raw.githubusercontent.com/K44DEUSZ/Gildiusz/${commit}`;
  const manifest = JSON.parse((await download(`${base}/manifest.json`, 16384)).toString("utf8"));
  validateBuild(manifest, sha, String(workflow.id));
  const bytes = await download(`${base}/${archiveName}`, manifest.size);
  return prepareRelease(root, manifest, bytes);
}

export function deploymentState(root, release) {
  return JSON.parse(
    run(
      process.execPath,
      [
        "--env-file=" + join(root, "shared", ".env"),
        "--input-type=module",
        "-e",
        'import {loadInstallations} from "./dist/installations.js";import {loadConfig} from "./dist/config.js";import {lintContent} from "./dist/content.js";const entries=loadInstallations();if(process.env.PUBLIC_INSTALLS==="1"){const {PublicInstallations}=await import("./dist/control/installations.js");const {healthPath}=await import("./dist/installations.js");const {dirname,join}=await import("node:path");const registry=new PublicInstallations(process.env.CONTROL_DATA_DIR||join(dirname(healthPath()),"public-guilds"));for(const entry of registry.values())if(!entries.some(value=>value.guildId===entry.guildId))entries.push(entry);}for(const entry of entries){if(entry.public)continue;const errors=lintContent(loadConfig(entry.configPath));if(errors.length)throw Error("Invalid guild configuration.");}console.log(JSON.stringify(entries.map(({guildId,databasePath})=>({guildId,databasePath}))));',
      ],
      release,
    ),
  );
}

export function backupEnvironmentArguments(root) {
  const args = ["--env-file=" + join(root, "shared", ".env")],
    file = join(root, "shared", "backup-key.env");
  let stat;
  try {
    stat = lstatSync(file);
  } catch (error) {
    if (error.code === "ENOENT") return args;
    throw Error("Cannot inspect the private backup environment.", { cause: error });
  }
  privateDirectory(join(root, "shared"));
  regularFile(file);
  if (
    stat.size < 1 ||
    stat.size > 4096 ||
    (process.platform !== "win32" &&
      ((stat.mode & 0o077) !== 0 || (process.getuid && stat.uid !== process.getuid())))
  )
    throw Error("Use an owned private backup environment with mode0600.");
  const values = parseEnv(readFileSync(file, "utf8"));
  if (
    Object.keys(values).join(",") !== "BACKUP_ENCRYPTION_KEY" ||
    !/^[A-Za-z0-9_-]{43}$/.test(values.BACKUP_ENCRYPTION_KEY)
  )
    throw Error("The backup environment may contain only its independent encryption key.");
  // Only recovery subprocesses read this file; it is not loaded into the worker environment.
  return [...args, "--env-file=" + file];
}

export async function stoppedSnapshot({ preflight, stop, snapshot }) {
  await preflight();
  await stop();
  return snapshot();
}

export function deploymentPause(root) {
  const path = paths(root).pause,
    marker = `Deployment in progress ${randomUUID()}\n`;
  writeFileSync(path, marker, { flag: "wx", mode: 0o600, flush: true });
  return () => {
    if (!existsSync(path) || readFileSync(path, "utf8") !== marker)
      throw Error("Deployment pause changed; explicit operator review is required.");
    rmSync(path);
  };
}

export function offsiteLocation(root) {
  const value = JSON.parse(
    readOffsiteFile(join(root, "shared", "offsite-location.json")).toString("utf8"),
  );
  if (
    Object.keys(value).sort().join() !== "format,locationId" ||
    value.format !== 1 ||
    !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(value.locationId)
  )
    throw Error("Pin the actual private PC backup catalogue before preparing an update.");
  return value.locationId;
}
export function pendingUpgrade(root) {
  const path = join(root, "shared", "pending-upgrade.json");
  if (!existsSync(path)) return null;
  const value = JSON.parse(readOffsiteFile(path).toString("utf8"));
  if (
    Object.keys(value).sort().join() !==
      [
        "format",
        "revision",
        "previous",
        "upgradeId",
        "pause",
        "locationId",
        "state",
        "backupId",
        "sha256",
        "activatedAt",
        "holdPause",
      ]
        .sort()
        .join() ||
    value.format !== 1 ||
    typeof value.holdPause !== "boolean" ||
    !/^[a-f0-9]{40}$/.test(value.revision) ||
    (value.previous !== null && !/^[a-f0-9]{40}$/.test(value.previous)) ||
    !/^[a-f0-9-]{36}$/.test(value.upgradeId) ||
    !/^[a-f0-9-]{36}$/.test(value.locationId) ||
    typeof value.pause !== "string" ||
    !/^Deployment in progress [a-f0-9-]{36}\n$/.test(value.pause) ||
    !["preparing", "awaiting_offsite", "activating", "failed"].includes(value.state) ||
    (value.backupId !== null && !/^[a-f0-9-]{36}$/.test(value.backupId)) ||
    (value.sha256 !== null && !/^[a-f0-9]{64}$/.test(value.sha256)) ||
    (value.activatedAt !== null &&
      (!Number.isSafeInteger(value.activatedAt) || value.activatedAt < 0))
  )
    throw Error("Pending update requires operator reconciliation.");
  return value;
}
export function beginUpgrade(root, revision, previous, locationId, { adoptPause = false } = {}) {
  if (
    !/^[a-f0-9]{40}$/.test(revision) ||
    (previous !== null && !/^[a-f0-9]{40}$/.test(previous)) ||
    !/^[a-f0-9-]{36}$/.test(locationId) ||
    typeof adoptPause !== "boolean"
  )
    throw Error("Invalid prepared update identity.");
  if (pendingUpgrade(root)) throw Error("A prepared update already exists.");
  if (adoptPause) {
    readOffsiteFile(paths(root).pause); // Explicit operator-only adoption; never used by automatic updates.
    writeOffsiteFile(paths(root).pause, Buffer.from(`Deployment in progress ${randomUUID()}\n`));
  } else deploymentPause(root);
  syncDirectory(join(root, "shared"));
  const value = {
    format: 1,
    revision,
    previous,
    upgradeId: randomUUID(),
    pause: readFileSync(paths(root).pause, "utf8"),
    locationId,
    state: "preparing",
    backupId: null,
    sha256: null,
    activatedAt: null,
    holdPause: adoptPause,
  };
  writeOffsiteFile(
    join(root, "shared", "pending-upgrade.json"),
    Buffer.from(JSON.stringify(value)),
  );
  return pendingUpgrade(root);
}
export function advanceUpgrade(root, expected, patch) {
  if (JSON.stringify(pendingUpgrade(root)) !== JSON.stringify(expected))
    throw Error("Prepared update changed; operator review required.");
  const value = { ...expected, ...patch };
  writeOffsiteFile(
    join(root, "shared", "pending-upgrade.json"),
    Buffer.from(JSON.stringify(value)),
  );
  return pendingUpgrade(root);
}
export function assertUpgradePause(root, pending) {
  if (
    JSON.stringify(pendingUpgrade(root)) !== JSON.stringify(pending) ||
    offsiteLocation(root) !== pending.locationId ||
    readOffsiteFile(paths(root).pause).toString("utf8") !== pending.pause
  )
    throw Error("Prepared update pause or PC identity changed; operator review required.");
}
export function acquireUpgradePause(root, pending) {
  if (pending.holdPause || existsSync(paths(root).pause)) {
    assertUpgradePause(root, pending);
    return pending;
  }
  if (
    JSON.stringify(pendingUpgrade(root)) !== JSON.stringify(pending) ||
    offsiteLocation(root) !== pending.locationId
  )
    throw Error("Prepared update changed; operator review required.");
  deploymentPause(root);
  syncDirectory(join(root, "shared"));
  return advanceUpgrade(root, pending, { pause: readFileSync(paths(root).pause, "utf8") });
}
export async function releaseAwaitingUpgrade(root, pending, resume) {
  if (pending.holdPause) return false;
  assertUpgradePause(root, pending);
  if (
    pending.state !== "awaiting_offsite" ||
    !pending.previous ||
    basename(realpathSync(paths(root).current)) !== pending.previous
  )
    throw Error("Only the unchanged previous release may resume while awaiting its PC receipt.");
  rmSync(paths(root).pause);
  syncDirectory(join(root, "shared"));
  try {
    await resume();
  } catch (error) {
    if (!existsSync(paths(root).pause))
      writeFileSync(paths(root).pause, pending.pause, { mode: 0o600, flag: "wx", flush: true });
    syncDirectory(join(root, "shared"));
    throw error;
  }
  return true;
}
export async function authorizePreparedUpgrade(root, revision, verify) {
  let pending = pendingUpgrade(root);
  if (
    !pending ||
    pending.state !== "awaiting_offsite" ||
    pending.revision !== revision ||
    !pending.backupId ||
    !pending.sha256
  )
    throw Error("The update is not prepared for activation.");
  assertUpgradePause(root, pending);
  const checked = await verify(pending);
  assertUpgradePause(root, pending);
  if (
    checked?.offsiteSuccess !== true ||
    checked.id !== pending.backupId ||
    checked.sha256 !== pending.sha256 ||
    checked.checkpoint?.upgradeId !== pending.upgradeId ||
    checked.checkpoint?.revision !== revision ||
    checked.checkpoint?.offsite?.destinationLocationId !== pending.locationId ||
    !checked.checkpoint?.offsiteAck?.signedReceipt
  )
    throw Error("A verified matching PC receipt is required before activation.");
  pending = advanceUpgrade(root, pending, { state: "activating", activatedAt: Date.now() });
  return pending;
}

function backupCheckpoint(root, release, command, args, input, sourceDirectory = release) {
  try {
    return JSON.parse(
      execFileSync(
        process.execPath,
        [
          ...backupEnvironmentArguments(root),
          join(release, "scripts", "backup-scheduler.mjs"),
          command,
          join(root, "shared", "backups"),
          ...args,
        ],
        {
          cwd: sourceDirectory,
          env: environment,
          encoding: "utf8",
          input: input ? JSON.stringify(input) : undefined,
          stdio: ["pipe", "pipe", "pipe"],
          timeout: 300000,
          maxBuffer: 1024 * 1024,
        },
      ),
    );
  } catch {
    throw Error("Backup checkpoint verification failed; the update was not approved.");
  }
}

export function assertUpdateRuntime(release) {
  if (readJson(join(release, "build.json"))?.runtimeFormat !== 6)
    throw Error(
      "New updates require runtime format6 with verified deletion lifecycle ports and no audio runtime.",
    );
  assertRuntimePackage(release, { format: 6 });
}

function inspectRelease(root, inspector, supported, quiescent) {
  return JSON.parse(
    run(
      process.execPath,
      [
        "--env-file=" + join(root, "shared", ".env"),
        join(inspector, "scripts", "deployment-state.mjs"),
        quiescent ? "quiescent" : "live",
        supported,
      ],
      supported,
    ),
  );
}

export function deploymentHealthy(health, guildIds, now = Date.now(), after = 0) {
  const actual = health?.guilds;
  return Boolean(
    healthy(health, now, after) &&
    health.updated <= now &&
    health.degraded === false &&
    health.rulesDeletionProof?.state === "ready" &&
    Array.isArray(actual) &&
    guildIds.length > 0 &&
    actual.length === guildIds.length &&
    actual.every((guild) => guild.ready === true) &&
    JSON.stringify(actual.map((guild) => guild.guildId).sort()) ===
      JSON.stringify([...guildIds].sort()),
  );
}

/** One code activation path. Recovery commands remain separate operator actions. */
export async function activateRelease(root, release, services = {}) {
  const p = paths(root),
    previous = realpathSync(p.current),
    sha = basename(release);
  if (entryExists(join(p.shared, "pending-upgrade.json")) || entryExists(p.pause))
    throw Error("Pending maintenance requires operator reconciliation before deployment.");
  if (previous === release) return event(root, `already active ${sha}`);
  const inspect =
      services.inspect ??
      ((supported, quiescent) => inspectRelease(root, release, supported, quiescent)),
    stop = services.stop ?? (() => stopSupervisor(root)),
    start = services.start ?? (() => startSupervisor(root)),
    select = services.select ?? ((target) => pointTo(root, target)),
    wait = services.wait ?? ((revision, after, guilds) => waitReady(root, revision, after, guilds)),
    currentMain =
      services.currentMain ??
      (() =>
        run("git", ["ls-remote", "origin", "refs/heads/main"], join(root, "source")).split(
          /\s/,
        )[0]);
  const baseline = await inspect(previous, false);
  const candidate = await inspect(release, false);
  assertSameDeploymentState(baseline, candidate);
  const guildIds = baseline.databases.map(({ guildId }) => guildId);
  if (
    !deploymentHealthy(readJson(p.health), guildIds, Date.now(), candidate.source.updatedAt ?? 0) ||
    readJson(p.state)?.release !== basename(previous)
  )
    throw Error("Deployment requires the complete healthy previous installation.");
  if ((await currentMain()) !== sha)
    throw Error("Main advanced before deployment; retry the current main.");
  const resume = deploymentPause(root),
    marker = readFileSync(p.pause, "utf8");
  const hold = () => {
    if (!existsSync(p.pause))
      writeFileSync(p.pause, marker, { flag: "wx", mode: 0o600, flush: true });
    if (readFileSync(p.pause, "utf8") !== marker)
      throw Error("Deployment pause changed; operator review required.");
  };
  const assertCurrent = (expected) => {
    if (realpathSync(p.current) !== expected || entryExists(join(p.shared, "pending-upgrade.json")))
      throw Error("Deployment selection or pending maintenance changed.");
  };
  let selected = false;
  try {
    await stop();
    hold();
    assertCurrent(previous);
    assertSameDeploymentState(baseline, await inspect(release, true));
    if ((await currentMain()) !== sha)
      throw Error("Main advanced before activation; retry the current main.");
    select(release);
    selected = true;
    const activated = Date.now();
    resume();
    await start();
    if (!(await wait(sha, activated, guildIds))) throw Error("New release did not become healthy.");
    assertCurrent(release);
  } catch (error) {
    // Stop the candidate before inspecting data; never restore a database or a deletion journal.
    hold();
    await stop();
    assertCurrent(selected ? release : previous);
    try {
      assertSameDeploymentState(baseline, await inspect(previous, true));
    } catch {
      event(root, "deployment paused: data compatibility requires operator review");
      throw Error("Deployment remains paused; code rollback is not verified.", { cause: error });
    }
    if (selected) {
      writeFileSync(join(p.shared, "failed-revision"), sha, { mode: 0o600 });
      select(previous);
    }
    const restarted = Date.now();
    resume();
    await start();
    if (!(await wait(basename(previous), restarted, guildIds))) {
      hold();
      await stop();
      throw Error("Previous release did not become healthy; deployment remains paused.", {
        cause: error,
      });
    }
    throw Error("Deployment refused; previous code is healthy and current data was preserved.", {
      cause: error,
    });
  }
  rmSync(join(p.shared, "failed-revision"), { force: true });
  event(root, `activation healthy ${sha}; no backup performed`);
  try {
    const removed = pruneReleases(root, basename(previous));
    if (removed.length) event(root, `pruned old releases count=${removed.length}`);
  } catch (error) {
    event(root, `release cleanup skipped: ${error.message}`);
  }
}

export async function install(root, sha, checked) {
  if (!/^[a-f0-9]{40}$/.test(sha ?? "")) throw Error("Expected a full commit SHA.");
  if (entryExists(join(root, "shared", "pending-upgrade.json")) || entryExists(paths(root).pause))
    throw Error("Pending maintenance requires operator reconciliation before deployment.");
  const workflow = checked ?? (await checkedWorkflow(sha));
  if (!workflow || !checkedRun([workflow], sha, "main"))
    throw Error("This revision has no successful main push checks.");
  const release = await retrieveRelease(root, sha, workflow);
  deploymentState(root, release);
  assertUpdateRuntime(release);
  assertDeploymentRuntime(release);
  return activateRelease(root, release);
}
async function update(root) {
  if (!existsSync(join(root, "shared", "autodeploy-enabled"))) return;
  const source = join(root, "source");
  if (!expectedRepository(run("git", ["remote", "get-url", "origin"], source)))
    throw Error("Unexpected source repository.");
  run("git", ["fetch", "--quiet", "origin", "main"], source);
  const sha = run("git", ["rev-parse", "FETCH_HEAD"], source);
  if (existsSync(paths(root).current) && basename(realpathSync(paths(root).current)) === sha)
    return;
  const failed = join(root, "shared", "failed-revision");
  if (existsSync(failed) && readFileSync(failed, "utf8") === sha) return;
  const workflow = await checkedWorkflow(sha);
  if (!workflow) return event(root, `waiting for successful main checks and package ${sha}`);
  // Do not activate an older revision if main advanced while checks were being read.
  const remote = run("git", ["ls-remote", "origin", "refs/heads/main"], source).split(/\s/)[0];
  if (remote !== sha) return event(root, "main advanced; waiting for the next scheduler run");
  await install(root, sha, workflow);
}

async function main() {
  const [command, argument, sha] = process.argv.slice(2);
  if (!argument)
    throw Error("Usage: hosting.mjs tick|status|install|restart|pause|resume|cleanup ROOT [SHA]");
  const root = resolve(argument);
  const p = paths(root);
  for (const directory of [p.shared, join(p.shared, "data"), join(p.shared, "logs")])
    mkdirSync(directory, { recursive: true, mode: 0o700 });
  if (command === "supervise") return supervise(root);
  if (["install", "import-offsite-ack"].includes(command)) {
    return console.log(
      run(
        "flock",
        [
          "-o",
          "-n",
          join(p.shared, "deploy.lock"),
          process.execPath,
          fileURLToPath(import.meta.url),
          command === "import-offsite-ack" ? "import-offsite-ack-locked" : "install-locked",
          root,
          sha,
        ],
        root,
      ),
    );
  }
  if (command === "install-locked") return install(root, sha);
  if (command === "import-offsite-ack-locked") {
    let pending = pendingUpgrade(root);
    if (!pending || pending.state !== "awaiting_offsite" || !sha)
      throw Error("No prepared checkpoint awaits a PC receipt.");
    pending = acquireUpgradePause(root, pending);
    await stopSupervisor(root);
    const release = join(root, "releases", pending.revision);
    assertUpdateRuntime(release);
    let checked;
    try {
      checked = backupCheckpoint(
        root,
        release,
        "import-offsite-ack",
        [
          "--id",
          pending.backupId,
          "--target-revision",
          pending.revision,
          "--upgrade-id",
          pending.upgradeId,
          "--pc-location",
          pending.locationId,
          "--receipt",
          resolve(sha),
        ],
        undefined,
        pending.previous ? join(root, "releases", pending.previous) : release,
      );
      assertUpgradePause(root, pending);
    } finally {
      if (JSON.stringify(pendingUpgrade(root)) === JSON.stringify(pending))
        await releaseAwaitingUpgrade(root, pending, () => startSupervisor(root));
    }
    console.log(
      JSON.stringify({
        state: "offsite_verified",
        id: checked.id,
        sha256: checked.sha256,
        offsiteSuccess: checked.offsiteSuccess,
      }),
    );
    return;
  }
  if (command === "update") return update(root);
  if (command === "cleanup") {
    if (!/^[a-f0-9]{40}$/.test(sha ?? "")) throw Error("Specify the rollback release SHA.");
    console.log(
      run(
        "flock",
        [
          "-n",
          join(p.shared, "deploy.lock"),
          process.execPath,
          join(root, "current", "scripts", "hosting.mjs"),
          "cleanup-locked",
          root,
          sha,
        ],
        root,
      ),
    );
    return;
  }
  if (command === "cleanup-locked") {
    const active = realpathSync(p.current);
    const state = readJson(p.state),
      health = readJson(p.health);
    if (
      !healthy(health) ||
      health.guilds?.some((guild) => !guild.ready) ||
      state?.release !== basename(active)
    )
      throw Error("Cleanup requires a healthy current deployment.");
    if (!expectedRepository(run("git", ["remote", "get-url", "origin"], join(root, "source"))))
      throw Error("Unexpected source repository.");
    const removedReleases = pruneReleases(root, sha);
    const legacy = cleanLegacyBuild(root);
    const receipt = {
      time: new Date().toISOString(),
      current: basename(active),
      previous: sha,
      removedReleases,
      ...legacy,
    };
    atomicJson(join(p.shared, "logs", "cleanup.json"), receipt);
    event(
      root,
      `cleanup completed: old releases=${removedReleases.length}; legacy=${legacy.removed.length}`,
    );
    console.log(JSON.stringify(receipt));
    return;
  }
  if (command === "status") {
    console.log(
      JSON.stringify({
        ...readJson(p.state),
        health: readJson(p.health),
        healthy: healthy(readJson(p.health)),
        pendingUpgrade: pendingUpgrade(root)
          ? {
              state: pendingUpgrade(root).state,
              revision: pendingUpgrade(root).revision,
              backupId: pendingUpgrade(root).backupId,
            }
          : null,
      }),
    );
    return;
  }
  if (["pause", "resume"].includes(command) && pendingUpgrade(root))
    throw Error("A prepared update owns the pause; reconcile or activate it explicitly.");
  if (command === "pause") writeFileSync(p.pause, "Paused by operator.\n", { mode: 0o600 });
  else if (command === "resume") rmSync(p.pause, { force: true });
  else if (command === "restart") writeFileSync(p.restart, String(Date.now()), { mode: 0o600 });
  else if (command !== "tick") throw Error("Unknown hosting command.");
  if (
    command === "tick" &&
    readJson(p.state)?.supervisorRevision !== basename(realpathSync(p.current))
  )
    await stopSupervisor(root);
  if (command === "tick") {
    try {
      rotateLogs(root);
    } catch (error) {
      event(root, `log rotation skipped: ${error.message}`);
    }
  }
  background(root, "supervise", "supervisor.lock");
  if (command === "tick") background(root, "update", "deploy.lock");
}

if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href)
  main().catch((error) => {
    // Subprocess stderr may contain configuration values; keep errors at the command level.
    console.error(error.message.split("\n")[0]);
    process.exitCode = 1;
  });
